#include "stdio.h"


//Anemo
#define continu (unsigned int *) NIOSANEMOMETRE_0_BASE
#define data (unsigned int *) (NIOSANEMOMETRE_0_BASE + 4)
//Verin
#define freq (int*) NIOSVERIN_0_BASE
#define duty (int*) (NIOSVERIN_0_BASE + 4)
#define butee_g (int*) (NIOSVERIN_0_BASE + 8)
#define butee_d (int*) (NIOSVERIN_0_BASE + 12)
#define config (int*) (NIOSVERIN_0_BASE + 16)
#define angle_barre (int*) (NIOSVERIN_0_BASE + 20)


//---------------------------------------------------------------------------

int get_anemo()
{
  *continu = 0x2;

	  int anemo_data = *data;
	  printf("%d \n", anemo_data & 0xFF);
	  usleep(100000);
	 return anemo_data & 0xFF;
  }

void get_verin()
{
	unsigned int c,d;

		*butee_d = 2000;
		*butee_g = 410;
		*freq = 5000;
		*duty = 4000;
		*config = 3;
	  	c=*freq;
	  	printf("freq= %d\n", c);

	  	d=*duty;
	  	printf("duty= %d\n", d);
	  	c=*butee_d;
	  	printf("butee_d= %d\n", c);
	  	d=*butee_g;
	  	printf("butee_g= %d\n", d);
	  	c=*config;
	  	printf("config= %d\n", c);
	  	d=*angle_barre;
	  	printf("angle_barre= %d\n", d);
	  usleep(100000);


  }
